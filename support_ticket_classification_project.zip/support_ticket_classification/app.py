from pathlib import Path
import pandas as pd
import streamlit as st
from src.classifier import load_model, predict_category
from src.priority import assign_priority

st.set_page_config(page_title="Support Ticket Classifier", page_icon="🎫", layout="wide")
st.title("🎫 Support Ticket Classification")
st.caption("Automatically classify customer support messages and assign an explainable priority.")

@st.cache_resource
def get_model():
    return load_model()

try:
    model = get_model()
except FileNotFoundError:
    st.error("The model has not been trained yet. Run `python train.py` in the project folder, then refresh.")
    st.stop()

tab1, tab2 = st.tabs(["Classify a ticket", "Batch classify CSV"])

with tab1:
    ticket = st.text_area("Customer support ticket", height=150,
                          placeholder="Example: I was charged twice and need this corrected.")
    if st.button("Classify ticket", type="primary"):
        if not ticket.strip():
            st.warning("Enter a ticket message first.")
        else:
            category, confidence = predict_category(model, ticket)
            priority, reason = assign_priority(ticket)
            c1, c2, c3 = st.columns(3)
            c1.metric("Predicted category", category)
            c2.metric("Priority", priority)
            c3.metric("Model confidence", f"{confidence:.1%}")
            st.info("Priority reasoning: " + reason)
            if confidence < 0.45:
                st.warning("Low model confidence: route this ticket for human review.")

with tab2:
    st.write("Upload a CSV containing a `ticket_text` column.")
    uploaded = st.file_uploader("Choose CSV", type=["csv"])
    if uploaded is not None:
        df = pd.read_csv(uploaded)
        if "ticket_text" not in df.columns:
            st.error("CSV must contain a `ticket_text` column.")
        else:
            outputs = []
            for ticket_text in df["ticket_text"].fillna("").astype(str):
                category, confidence = predict_category(model, ticket_text)
                priority, reason = assign_priority(ticket_text)
                outputs.append({
                    "predicted_category": category,
                    "category_confidence": round(confidence, 4),
                    "priority": priority,
                    "priority_reason": reason
                })
            result = pd.concat([df.reset_index(drop=True), pd.DataFrame(outputs)], axis=1)
            st.dataframe(result, use_container_width=True)
            st.download_button("Download classified tickets",
                               result.to_csv(index=False).encode("utf-8"),
                               file_name="classified_tickets.csv",
                               mime="text/csv")
