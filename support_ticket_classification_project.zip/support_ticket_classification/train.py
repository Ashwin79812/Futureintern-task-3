from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from src.classifier import train_model

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "sample_tickets.csv"

def main():
    df = pd.read_csv(DATA_PATH).dropna(subset=["ticket_text", "category"])
    X_train, X_test, y_train, y_test = train_test_split(
        df["ticket_text"], df["category"], test_size=0.25,
        random_state=42, stratify=df["category"]
    )
    model = train_model(X_train, y_train)
    print(f"Trained category model using {len(X_train)} tickets.")
    print(f"Hold-out test tickets: {len(X_test)}")
    print("Model saved to models/ticket_category_model.joblib")
    print("Run `python evaluate.py` to review test metrics.")

if __name__ == "__main__":
    main()
