from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, ConfusionMatrixDisplay, accuracy_score
from src.classifier import build_model

ROOT = Path(__file__).resolve().parent

def main():
    df = pd.read_csv(ROOT / "data" / "sample_tickets.csv").dropna(subset=["ticket_text", "category"])
    X_train, X_test, y_train, y_test = train_test_split(
        df["ticket_text"], df["category"], test_size=0.25,
        random_state=42, stratify=df["category"]
    )
    model = build_model()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    report = classification_report(y_test, predictions, output_dict=True, zero_division=0)
    (ROOT / "reports").mkdir(exist_ok=True)
    with open(ROOT / "reports" / "classification_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print("Accuracy:", round(accuracy_score(y_test, predictions), 4))
    print(classification_report(y_test, predictions, zero_division=0))
    ConfusionMatrixDisplay.from_predictions(y_test, predictions, xticks_rotation=35)
    plt.tight_layout()
    plt.savefig(ROOT / "reports" / "confusion_matrix.png", dpi=160)
    print("Saved reports/classification_report.json and reports/confusion_matrix.png")

if __name__ == "__main__":
    main()
