from pathlib import Path
import joblib
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

MODEL_PATH = Path(__file__).resolve().parents[1] / "models" / "ticket_category_model.joblib"

def build_model() -> Pipeline:
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            preprocessor=lambda x: str(x).lower(),
            stop_words="english",
            ngram_range=(1, 2),
            max_features=12000
        )),
        ("classifier", LogisticRegression(max_iter=1500, class_weight="balanced"))
    ])

def train_model(texts, labels):
    model = build_model()
    model.fit(texts, labels)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    return model

def load_model():
    if not MODEL_PATH.exists():
        raise FileNotFoundError("Model not found. Run `python train.py` first.")
    return joblib.load(MODEL_PATH)

def predict_category(model, text: str):
    category = model.predict([text])[0]
    probabilities = model.predict_proba([text])[0]
    confidence = float(max(probabilities))
    return category, confidence
