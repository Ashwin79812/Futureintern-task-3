HIGH_TERMS = {
    "urgent", "critical", "immediately", "cannot access", "locked out",
    "system down", "outage", "fraud", "hacked", "security breach",
    "payment failed", "business stopped", "data loss"
}
MEDIUM_TERMS = {
    "not working", "error", "delayed", "charged twice", "wrong amount",
    "cannot login", "can't login", "missing", "damaged", "late"
}

def assign_priority(ticket_text: str) -> tuple[str, str]:
    """Return (priority, explanation) using explainable keyword rules."""
    text = str(ticket_text or "").lower()
    high = [term for term in HIGH_TERMS if term in text]
    medium = [term for term in MEDIUM_TERMS if term in text]
    if high:
        return "High", "Urgency/impact terms detected: " + ", ".join(sorted(high))
    if medium:
        return "Medium", "Issue or delay terms detected: " + ", ".join(sorted(medium))
    return "Low", "No configured high- or medium-urgency terms detected."
