import re
from typing import List

def clean_text(text: str) -> str:
    """Normalize a ticket message without removing useful support terms."""
    text = str(text or "").lower()
    text = re.sub(r"https?://\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def tokenize_text(text: str) -> List[str]:
    """Use spaCy if available; otherwise use a lightweight regex tokenizer."""
    cleaned = clean_text(text)
    try:
        import spacy
        try:
            nlp = spacy.load("en_core_web_sm", disable=["parser", "ner"])
            return [t.lemma_ for t in nlp(cleaned) if not t.is_stop and not t.is_punct]
        except OSError:
            pass
    except ImportError:
        pass
    return re.findall(r"[a-z0-9']+", cleaned)
